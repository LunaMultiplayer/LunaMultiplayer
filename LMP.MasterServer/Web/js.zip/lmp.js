$(document).ready(function() 
    { 
        $("#LmpTable").tablesorter( {sortList: [[6,1]]} ); 
    } 
); 