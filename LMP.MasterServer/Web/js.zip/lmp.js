$(document).ready(function() 
    { 
        $("#LmpTable").tablesorter( {sortList: [[5,1], [3,0]]} ); 
    } 
); 