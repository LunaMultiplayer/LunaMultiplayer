$(document).ready(function() 
    { 
        $("#LmpTable").tablesorter( {sortList: [[7,1]]} ); 
    } 
);
